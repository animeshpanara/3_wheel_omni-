DuePWM
======

PWM Library for Arduino Due 


This library was originally contributed by exedor at http://forum.arduino.cc/index.php?topic=146947.msg1282508#msg1282508